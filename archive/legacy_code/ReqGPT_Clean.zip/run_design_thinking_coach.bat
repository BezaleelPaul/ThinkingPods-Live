@echo off
set PYTHON=C:\Users\bezal\AppData\Local\Programs\Python\Python312\python.exe

rem --- LLM Base Model Configuration ---
rem Default is deepseek-r1:1.5b. Change to any model you want to use as base (e.g. B-A-M-N/vibethinker:1.5b)
set OLLAMA_BASE_MODEL=llama3.2:1b

rem --- Voice Transcription (STT) Model Configuration ---
rem Options: tiny.en, base.en (default), small.en (recommended for better accuracy), medium.en
rem Note: larger models take more RAM and CPU but have much better accuracy.
set WHISPER_MODEL=tiny.en

echo Checking for existing processes on port 8000...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8000 ^| findstr LISTENING') do (
    echo Killing process %%a using port 8000...
    taskkill /F /PID %%a
)

echo Loading Design Thinking Coach (Pure Question-Based Assistant)...
"%PYTHON%" design_thinking_coach.py
pause