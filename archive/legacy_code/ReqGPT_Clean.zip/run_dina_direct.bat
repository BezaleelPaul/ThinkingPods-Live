@echo off
title Dina Direct - 100%% Offline

rem --- LLM Base Model Configuration ---
rem Default is deepseek-r1:1.5b. Change to any model you want to use as base (e.g. B-A-M-N/vibethinker:1.5b)
set OLLAMA_BASE_MODEL=llama3.2:1b

rem --- Voice Transcription (STT) Model Configuration ---
rem Options: tiny.en, base.en (default), small.en (recommended for better accuracy), medium.en
rem Note: larger models take more RAM and CPU but have much better accuracy.
set WHISPER_MODEL=tiny.en
set PYTHON=C:\Users\bezal\AppData\Local\Programs\Python\Python312\python.exe

echo Running Dynamic Hardware Auto-Tweaker...
"%PYTHON%" autotweak.py

echo ===========================================
echo   DINA DIRECT - SIMPLIFIED OFFLINE VOICE
echo ===========================================
echo 1. Ensure Ollama is running in background.
echo 2. loading models (Whisper + Silero)...
echo.
"%PYTHON%" dina_direct.py
pause