@echo off
set PYTHON=C:\Users\bezal\AppData\Local\Programs\Python\Python312\python.exe

rem --- LLM Base Model Configuration ---
rem Default is deepseek-r1:1.5b. Change to any model you want to use as base (e.g. B-A-M-N/vibethinker:1.5b)
set OLLAMA_BASE_MODEL=llama3.2:1b

echo Starting Text-Based Design Thinking Coach...
"%PYTHON%" design_thinking_coach_text.py
pause