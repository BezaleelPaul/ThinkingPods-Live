import os
import json
import re
import ollama

class MentorSession:
    def __init__(self, username="User", project_name="MyProject"):
        self.username = username
        self.project_name = project_name
        self.current_stage = "Empathize"
        
        # Checklist items (Empathize required info)
        self.target_audience = None
        self.pain_point = None
        self.motivation = None
        self.existing_solution = None
        self.frequency = None
        self.evidence = None
        
        # Structured knowledge collections
        self.known_facts = []
        self.unknown_facts = []
        self.assumptions = []
        self.open_questions = []
        self.previous_questions = []
        self.raw_history = []  # list of dicts: {"role": str, "content": str}

    def to_dict(self):
        return {
            "username": self.username,
            "project_name": self.project_name,
            "current_stage": self.current_stage,
            "target_audience": self.target_audience,
            "pain_point": self.pain_point,
            "motivation": self.motivation,
            "existing_solution": self.existing_solution,
            "frequency": self.frequency,
            "evidence": self.evidence,
            "known_facts": self.known_facts,
            "unknown_facts": self.unknown_facts,
            "assumptions": self.assumptions,
            "open_questions": self.open_questions,
            "previous_questions": self.previous_questions,
            "raw_history": self.raw_history
        }

    @classmethod
    def from_dict(cls, d):
        s = cls(d.get("username", "User"), d.get("project_name", "MyProject"))
        s.current_stage = d.get("current_stage", "Empathize")
        s.target_audience = d.get("target_audience")
        s.pain_point = d.get("pain_point")
        s.motivation = d.get("motivation")
        s.existing_solution = d.get("existing_solution")
        s.frequency = d.get("frequency")
        s.evidence = d.get("evidence")
        s.known_facts = d.get("known_facts", [])
        s.unknown_facts = d.get("unknown_facts", [])
        s.assumptions = d.get("assumptions", [])
        s.open_questions = d.get("open_questions", [])
        s.previous_questions = d.get("previous_questions", [])
        s.raw_history = d.get("raw_history", [])
        return s

class MemoryManager:
    @staticmethod
    def get_filepath(username, project_name):
        safe_user = re.sub(r'[^a-zA-Z0-9_-]', '', username) or "user"
        safe_proj = re.sub(r'[^a-zA-Z0-9_-]', '', project_name) or "project"
        os.makedirs("sessions", exist_ok=True)
        return os.path.join("sessions", f"{safe_user}_{safe_proj}_mentor.json")

    @staticmethod
    def save_session(session):
        filepath = MemoryManager.get_filepath(session.username, session.project_name)
        try:
            with open(filepath, "w") as f:
                json.dump(session.to_dict(), f, indent=2)
            print(f"Mentor session saved to {filepath}")
        except Exception as e:
            print(f"Error saving mentor session: {e}")

    @staticmethod
    def load_session(username, project_name):
        filepath = MemoryManager.get_filepath(username, project_name)
        if os.path.exists(filepath):
            try:
                with open(filepath, "r") as f:
                    data = json.load(f)
                return MentorSession.from_dict(data)
            except Exception as e:
                print(f"Error loading mentor session: {e}")
        return MentorSession(username, project_name)

class InputProcessor:
    @staticmethod
    def extract_structured_data(model, user_message, session):
        existing_details = {
            "project_name": session.project_name,
            "target_audience": session.target_audience,
            "pain_point": session.pain_point,
            "motivation": session.motivation,
            "existing_solution": session.existing_solution,
            "frequency": session.frequency,
            "evidence": session.evidence,
            "assumptions": session.assumptions,
            "unknown_facts": session.unknown_facts,
            "open_questions": session.open_questions
        }
        
        prompt = f"""You are an Information Extraction assistant. Analyze the user's message and extract design thinking data to update the existing project details.

Here are examples of how to perform the extraction:

Example 1:
User message: "I want to build an app for elderly people because my grandmother often forgets her medication."
Extracted JSON:
{{
  "project_name": "Medication Reminder",
  "target_audience": "elderly people",
  "pain_point": "forgetting medication",
  "motivation": "grandmother forgets medication",
  "existing_solution": null,
  "frequency": null,
  "evidence": null,
  "assumptions": [],
  "unknown_facts": [],
  "open_questions": []
}}

Example 2:
User message: "So we are making design thinking project on how we are going to implement it in software village about the rural to urban development."
Extracted JSON:
{{
  "project_name": "Sathnur Software Village",
  "target_audience": "rural villagers / village community",
  "pain_point": "implementing rural to urban development in software village",
  "motivation": "rural to urban development challenge",
  "existing_solution": null,
  "frequency": null,
  "evidence": null,
  "assumptions": [],
  "unknown_facts": [],
  "open_questions": []
}}

Example 3:
User message: "I'm going to give you a video. I don't know, it depends on that."
Extracted JSON:
{{
  "project_name": null,
  "target_audience": null,
  "pain_point": null,
  "motivation": null,
  "existing_solution": null,
  "frequency": null,
  "evidence": null,
  "assumptions": ["video content will determine details"],
  "unknown_facts": ["video details"],
  "open_questions": []
}}

Analyze the following user message:
User Message: "{user_message}"

Existing details:
{json.dumps(existing_details, indent=2)}

Respond ONLY with a JSON object containing the keys. Do not include markdown code block syntax (like ```json), no thinking tags, and no introductory or concluding sentences.
JSON Format:
{{
  "project_name": "value or null",
  "target_audience": "value or null",
  "pain_point": "value or null",
  "motivation": "value or null",
  "existing_solution": "value or null",
  "frequency": "value or null",
  "evidence": "value or null",
  "assumptions": ["string", ...] or [],
  "unknown_facts": ["string", ...] or [],
  "open_questions": ["string", ...] or []
}}
"""
        try:
            response = ollama.chat(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                options={"temperature": 0.1}
            )
            reply = response['message']['content'].strip()
            
            # Clean up thinking tags
            reply = re.sub(r'<think>.*?</think>', '', reply, flags=re.DOTALL).strip()
            
            # Extract JSON object
            start = reply.find('{')
            end = reply.rfind('}')
            if start != -1 and end != -1:
                json_str = reply[start:end+1]
                extracted = json.loads(json_str)
                return extracted
        except Exception as e:
            print(f"Error during structured extraction: {e}")
        return {}

class ChecklistManager:
    REQUIRED_ITEMS = [
        ("target_audience", "target audience"),
        ("pain_point", "pain point"),
        ("motivation", "motivation"),
        ("existing_solution", "existing solution or current workflow"),
        ("frequency", "frequency of the problem"),
        ("evidence", "evidence or observations validating the problem")
    ]
    
    @staticmethod
    def get_missing_items(session):
        missing = []
        for key, description in ChecklistManager.REQUIRED_ITEMS:
            val = getattr(session, key)
            if not val or val == "null" or val == "None":
                missing.append((key, description))
        return missing

    @staticmethod
    def get_status_dict(session):
        status = {}
        for key, description in ChecklistManager.REQUIRED_ITEMS:
            val = getattr(session, key)
            status[key] = {
                "complete": bool(val and val != "null" and val != "None"),
                "value": val if (val and val != "null" and val != "None") else None,
                "description": description
            }
        return status

class QuestionPlanner:
    @staticmethod
    def plan_next_question(session):
        # 1. Challenge assumptions if they exist and haven't been challenged yet
        if session.assumptions and len(session.assumptions) > len(session.evidence or ""):
            # Let's challenge the latest assumption
            unverified_assumption = session.assumptions[-1]
            return "challenge_assumption", f"Challenge the assumption: '{unverified_assumption}' and ask how they can validate it."

        # 2. Check standard checklist
        missing = ChecklistManager.get_missing_items(session)
        if not missing:
            return "summary", "Provide a comprehensive empathy summary of all gathered details and ask the user to confirm or refine it."
        
        # Pick the first missing item to ask about
        next_item_key, next_item_desc = missing[0]
        return next_item_key, f"Ask about their {next_item_desc}."

class PromptBuilder:
    @staticmethod
    def build_prompt(session, next_action_desc, next_item_key):
        known_facts = []
        if session.project_name:
            known_facts.append(f"- Project Name: {session.project_name}")
        if session.target_audience:
            known_facts.append(f"- Target Audience: {session.target_audience}")
        if session.pain_point:
            known_facts.append(f"- Pain Point: {session.pain_point}")
        if session.motivation:
            known_facts.append(f"- Motivation: {session.motivation}")
        if session.existing_solution:
            known_facts.append(f"- Existing Solution/Workflow: {session.existing_solution}")
        if session.frequency:
            known_facts.append(f"- Frequency of Problem: {session.frequency}")
        if session.evidence:
            known_facts.append(f"- Evidence/Proof: {session.evidence}")
            
        facts_str = "\n".join(known_facts) if known_facts else "- None yet"

        # List assumptions
        assumptions_str = ", ".join(session.assumptions) if session.assumptions else "None"
        unknowns_str = ", ".join(session.unknown_facts) if session.unknown_facts else "None"

        if next_item_key == "summary":
            prompt = f"""You are an AI Design Thinking Mentor guiding the user through the Empathize stage.
Current Stage: Empathize (Summary Phase)

Known Facts:
{facts_str}
Assumptions Tracked: {assumptions_str}
Unknowns Tracked: {unknowns_str}

Goal:
Convert the structured details above into a natural, highly empathetic summary. Acknowledge their personal connection (motivation) if mentioned. Ask the user if this summary is accurate and if they want to confirm it or make any changes before moving on.

Rules:
- NEVER provide solutions, suggestions, or recommendations during the Empathize stage.
- Keep the summary clear, human, and concise (under 4 sentences).
- Do NOT use markdown list formatting or bullet points in your reply. Keep it conversational.
- Do NOT use hashtags (#) or emojis.
"""
        elif next_item_key == "challenge_assumption":
            prompt = f"""You are an AI Design Thinking Mentor guiding the user through the Empathize stage.
Current Stage: Empathize (Challenging Assumptions)

Known Facts:
{facts_str}

Goal:
{next_action_desc}

Rules:
- NEVER provide solutions, suggestions, or recommendations.
- Ask ONLY one question.
- Do NOT sound robotic or accusatory. Challenge the assumption in a supportive, curious, and empathetic way (e.g. 'How might we find out if...?', or 'What makes us think that...?').
- Do NOT explain why you are asking. Just ask the question.
- Keep the response short (under 2 sentences).
"""
        else:
            prompt = f"""You are an AI Design Thinking Mentor guiding the user through the Empathize stage.
Current Stage: Empathize

Known Facts:
{facts_str}
Assumptions Tracked: {assumptions_str}
Unknowns Tracked: {unknowns_str}

Goal:
Ask a natural, context-aware question to gather information about: {next_action_desc}

Rules:
- NEVER provide solutions, suggestions, or recommendations during the Empathize stage. Focus only on understanding the problem.
- Ask ONLY one question.
- Do NOT sound robotic. Convert the structured request into a human, conversational, and empathetic prompt.
- Do NOT explain why you are asking. Just ask the question.
- Keep the response short (under 2 sentences).
"""
        return prompt

def merge_extracted_data(session, extracted):
    if not extracted:
        return
    
    # Clean string literals like "null", "None"
    def clean_val(v):
        if not v:
            return None
        s = str(v).strip()
        if s.lower() in ("null", "none", ""):
            return None
        return s

    proj = clean_val(extracted.get("project_name"))
    aud = clean_val(extracted.get("target_audience"))
    pain = clean_val(extracted.get("pain_point"))
    mot = clean_val(extracted.get("motivation"))
    sol = clean_val(extracted.get("existing_solution"))
    freq = clean_val(extracted.get("frequency"))
    evid = clean_val(extracted.get("evidence"))

    if proj:
        session.project_name = proj
    if aud:
        session.target_audience = aud
    if pain:
        session.pain_point = pain
    if mot:
        session.motivation = mot
    if sol:
        session.existing_solution = sol
    if freq:
        session.frequency = freq
    if evid:
        session.evidence = evid

    # Merge lists
    for item in extracted.get("assumptions", []):
        val = clean_val(item)
        if val and val not in session.assumptions:
            session.assumptions.append(val)
            
    for item in extracted.get("unknown_facts", []):
        val = clean_val(item)
        if val and val not in session.unknown_facts:
            session.unknown_facts.append(val)
            
    for item in extracted.get("open_questions", []):
        val = clean_val(item)
        if val and val not in session.open_questions:
            session.open_questions.append(val)

    # Rebuild known facts
    session.known_facts = []
    if session.project_name:
        session.known_facts.append(f"Project Name: {session.project_name}")
    if session.target_audience:
        session.known_facts.append(f"Target Audience: {session.target_audience}")
    if session.pain_point:
        session.known_facts.append(f"Pain Point: {session.pain_point}")
    if session.motivation:
        session.known_facts.append(f"Motivation: {session.motivation}")
    if session.existing_solution:
        session.known_facts.append(f"Existing Solution/Workflow: {session.existing_solution}")
    if session.frequency:
        session.known_facts.append(f"Frequency: {session.frequency}")
    if session.evidence:
        session.known_facts.append(f"Evidence: {session.evidence}")

def process_mentor_turn(user_message, username="User", project_name="MyProject", model_name="llama3.2:1b"):
    # 1. Load session
    session = MemoryManager.load_session(username, project_name)
    
    # Save raw turn in history
    session.raw_history.append({"role": "user", "content": user_message})
    
    # 2. Input Processing: Extract structured facts
    extracted = InputProcessor.extract_structured_data(model_name, user_message, session)
    merge_extracted_data(session, extracted)
    
    # 3. Question Planner: Plan next action based on checklist status
    next_item_key, next_action_desc = QuestionPlanner.plan_next_question(session)
    
    # 4. Prompt Builder: Build LLM prompt
    prompt = PromptBuilder.build_prompt(session, next_action_desc, next_item_key)
    
    # 5. LLM Call: Generate the natural language question
    try:
        response = ollama.chat(
            model=model_name,
            messages=[{"role": "user", "content": prompt}],
            options={
                "temperature": 0.4,
                "top_p": 0.8,
            }
        )
        reply = response['message']['content'].strip()
        # Clean up any thinking blocks
        reply = re.sub(r'<think>.*?</think>', '', reply, flags=re.DOTALL).strip()
    except Exception as e:
        print(f"Error during LLM question generation: {e}")
        # fallback question
        if next_item_key == "summary":
            reply = "Here is what I gathered. Can you tell me if this is correct?"
        else:
            reply = f"Could you tell me more about your {next_action_desc.replace('Ask about their ', '')}?"

    # Force question mark if it's not a summary and doesn't end with a question mark
    if next_item_key != "summary" and not reply.endswith("?"):
        reply += "?"

    session.raw_history.append({"role": "assistant", "content": reply})
    session.previous_questions.append(reply)
    
    # 6. Memory Manager: Save session state
    MemoryManager.save_session(session)
    
    return reply, session

def print_ascii_dashboard(session):
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    CYAN = '\033[96m'
    BOLD = '\033[1m'
    RESET = '\033[0m'
    
    print(f"\n{BOLD}{CYAN}============================================================{RESET}")
    print(f"{BOLD}{CYAN}            💡 AI DESIGN THINKING MENTOR (EMPATHIZE){RESET}")
    print(f"{BOLD}{CYAN}============================================================{RESET}")
    print(f"  {BOLD}Project Name:{RESET} {session.project_name if session.project_name else 'Not established yet'}")
    print(f"  {BOLD}Current Stage:{RESET} Empathize Phase")
    print(f"{CYAN}------------------------------------------------------------{RESET}")
    print(f"  {BOLD}📋 Required Checklist Status:{RESET}")
    
    status_dict = ChecklistManager.get_status_dict(session)
    for key, item in status_dict.items():
        desc = item["description"].title().ljust(35)
        if item["complete"]:
            print(f"    [{GREEN}✓{RESET}] {desc} : {item['value']}")
        else:
            print(f"    [{YELLOW}✗{RESET}] {desc} : {YELLOW}Missing / Gather in progress{RESET}")
            
    print(f"{CYAN}------------------------------------------------------------{RESET}")
    
    if session.assumptions:
        print(f"  {BOLD}🔍 Assumptions Tracked:{RESET}")
        for idx, asm in enumerate(session.assumptions):
            print(f"    {idx+1}. *{asm}* (Unvalidated)")
    else:
        print(f"  {BOLD}🔍 Assumptions Tracked:{RESET} None yet")
        
    if session.unknown_facts:
        print(f"  {BOLD}❓ Unknown Facts:{RESET}")
        for idx, unk in enumerate(session.unknown_facts):
            print(f"    {idx+1}. {unk}")
    else:
        print(f"  {BOLD}❓ Unknown Facts:{RESET} None yet")
        
    if session.open_questions:
        print(f"  {BOLD}💬 Open Questions:{RESET}")
        for idx, q in enumerate(session.open_questions):
            print(f"    {idx+1}. {q}")
    else:
        print(f"  {BOLD}💬 Open Questions:{RESET} None yet")
        
    print(f"{BOLD}{CYAN}============================================================{RESET}\n")
