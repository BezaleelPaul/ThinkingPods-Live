import streamlit as st
import requests
import os
import io
import json
from datetime import datetime
import urllib.parse
import re
import base64
from audio_recorder_streamlit import audio_recorder
from constants import MERMAID_KEYWORDS

# --- Backend Configuration ---
BACKEND_URL = "http://127.0.0.1:8000"

# --- Page Config ---
st.set_page_config(
    page_title="ReqGPT | Mission Control",
    page_icon="🚀",
    layout="centered"
)

# --- Inject Beautiful Cyberpunk / High-Tech CSS ---
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap');
    
    /* General Font override */
    html, body, [class*="css"], .stMarkdown {
        font-family: 'Outfit', sans-serif !important;
    }
    
    /* Main Background custom subtle gradient */
    .stApp {
        background: linear-gradient(135deg, #0e1117 0%, #151922 100%) !important;
    }
    
    /* Sleek Sidebar styling */
    section[data-testid="stSidebar"] {
        background-color: #0c0e14 !important;
        border-right: 1px solid #1f2937 !important;
    }
    
    /* Custom checklist items card styling */
    .checklist-card {
        background: rgba(255, 255, 255, 0.02);
        border: 1px solid rgba(255, 255, 255, 0.05);
        border-radius: 12px;
        padding: 14px;
        margin-bottom: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s, border 0.2s, background 0.2s;
    }
    .checklist-card:hover {
        transform: translateY(-2px);
        border-color: rgba(0, 123, 255, 0.4);
        background: rgba(255, 255, 255, 0.04);
    }
    
    /* Checklist complete state badge */
    .badge-complete {
        background: linear-gradient(90deg, #10b981 0%, #059669 100%) !important;
        color: white !important;
        font-size: 0.75rem;
        padding: 2px 8px;
        border-radius: 20px;
        font-weight: 600;
        float: right;
    }
    
    /* Checklist missing state badge */
    .badge-missing {
        background: linear-gradient(90deg, #f59e0b 0%, #d97706 100%) !important;
        color: white !important;
        font-size: 0.75rem;
        padding: 2px 8px;
        border-radius: 20px;
        font-weight: 600;
        float: right;
    }
    
    /* Card headers */
    .card-header {
        font-weight: 600;
        color: #f3f4f6;
        margin-bottom: 4px;
        font-size: 0.95rem;
    }
    
    /* Card values */
    .card-value {
        color: #9ca3af;
        font-size: 0.85rem;
        font-style: italic;
    }
</style>
""", unsafe_allow_html=True)

# --- Persistence Helpers ---
SESSION_DIR = "sessions"
os.makedirs(SESSION_DIR, exist_ok=True)

def save_session(name):
    data = {
        "messages": st.session_state.messages,
        "dt_phase": st.session_state.dt_phase,
        "timestamp": datetime.now().isoformat()
    }
    safe_name = re.sub(r'[^a-zA-Z0-9_-]', '', name) or "unnamed"
    filepath = os.path.join(SESSION_DIR, f"{safe_name}.json")
    try:
        with open(filepath, "w") as f:
            json.dump(data, f)
    except Exception as e:
        st.error(f"Failed to save session: {e}")

def load_session(name):
    safe_name = re.sub(r'[^a-zA-Z0-9_-]', '', name) or "unnamed"
    filepath = os.path.join(SESSION_DIR, f"{safe_name}.json")
    try:
        with open(filepath, "r") as f:
            data = json.load(f)
            st.session_state.messages = data["messages"]
            st.session_state.dt_phase = data["dt_phase"]
    except FileNotFoundError:
        st.error(f"Session '{name}' not found.")
    except Exception as e:
        st.error(f"Failed to load session: {e}")

# --- State Management ---
if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "assistant", "content": "Hello! I am ThinkingPods, your Design Thinking Consultant. Tell me, what project or idea are we working on today?"}
    ]
if "dt_phase" not in st.session_state:
    st.session_state.dt_phase = "Discovery"

# --- Backend Communication ---

def call_backend_text(text, phase, doc_ctx="", username="User"):
    try:
        payload = {
            "text": text, 
            "pod": phase, 
            "username": username, 
            "project_name": st.session_state.get("project_name", "MyProject"),
            "context_doc": doc_ctx, 
            "interaction_mode": st.session_state.get("interaction_mode", "Helpful Assistant"),
            "enable_voice": st.session_state.get("enable_voice", True)
        }
        response = requests.post(f"{BACKEND_URL}/text", json=payload)

        if response.status_code == 200:
            reply = urllib.parse.unquote(response.headers.get("X-Reply", ""))
            return reply, response.content # reply text and audio bytes
        else:
            try:
                err_msg = response.json().get("error", f"Error {response.status_code}")
            except Exception:
                err_msg = f"Error {response.status_code}"
            return f"⚠️ {err_msg}", None
    except Exception as e:
        return f"⚠️ Backend Unreachable: {e}", None

def call_backend_voice(audio_bytes, phase, doc_ctx="", username="User"):
    try:
        headers = {
            "X-Pod": phase,
            "X-Username": username,
            "X-Project-Name": urllib.parse.quote(st.session_state.get("project_name", "MyProject")),
            "X-Context-Doc": urllib.parse.quote(doc_ctx[:2000]), # Limit context size for headers
            "X-Interaction-Mode": st.session_state.get("interaction_mode", "Helpful Assistant"),
            "X-Enable-Voice": str(st.session_state.get("enable_voice", True))
        }
        response = requests.post(f"{BACKEND_URL}/voice", data=audio_bytes, headers=headers)

        if response.status_code == 200:
            transcript = urllib.parse.unquote(response.headers.get("X-Transcript", ""))
            reply = urllib.parse.unquote(response.headers.get("X-Reply", ""))
            return transcript, reply, response.content
        else:
            try:
                err_msg = response.json().get("error", f"Error {response.status_code}")
            except Exception:
                err_msg = f"Error {response.status_code}"
            return None, f"⚠️ {err_msg}", None
    except Exception as e:
        return None, f"⚠️ Backend Unreachable: {e}", None

def call_backend_reqgpt(prompt):
    try:
        payload = {"prompt": prompt}
        response = requests.post(f"{BACKEND_URL}/generate_requirements", json=payload)
        if response.status_code == 200:
            return response.json().get("requirement", "")
        else:
            return f"⚠️ Error: {response.json().get('error', 'Unknown error')}"
    except Exception as e:
        return f"⚠️ Backend Unreachable: {e}"

def call_backend_visualize(username="User", doc_ctx=""):
    try:
        payload = {"username": username, "context_doc": doc_ctx}
        response = requests.post(f"{BACKEND_URL}/visualize", json=payload)
        if response.status_code == 200:
            return response.text
        else:
            return "graph TD\n  A[⚠️ Backend Error] --> B[Could not generate]"
    except Exception as e:
        return f"graph TD\n  A[⚠️ Unreachable] --> B[{str(e)[:50]}]"

# --- Brain Logic (Moved to Backend) ---
# generate_chat_response is now handled by call_backend_text and call_backend_voice

# --- Mermaid Rendering ---
def render_mermaid(code):
    # Strip markdown code blocks if present
    code = code.replace("```mermaid", "").replace("```", "").strip()
    
    # Supported keywords
    if not any(k in code for k in MERMAID_KEYWORDS):
        return # Not mermaid code

    html_code = f"""
    <div id="mermaid-container" style="background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 20px;">
        <pre class="mermaid" style="display: flex; justify-content: center;">
            {code}
        </pre>
    </div>
    <script type="module">
        import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.esm.min.mjs';
        mermaid.initialize({{ 
            startOnLoad: true, 
            theme: 'base',
            themeVariables: {{
                'primaryColor': '#007bff',
                'edgeColor': '#555555'
            }},
            securityLevel: 'loose'
        }});
        // Force a re-render in case startOnLoad misses the dynamic content
        setTimeout(() => {{
            mermaid.contentLoaded();
        }}, 500);
    </script>
    """
    # Dynamic height based on lines of code (rough estimate)
    lines = code.count("\n")
    calc_height = max(400, (lines + 2) * 25)
    st.components.v1.html(html_code, height=calc_height, scrolling=True)

def format_prd():
    doc = f"# Product Requirements Document (PRD)\n"
    doc += f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n"
    doc += f"## Project Log\n"
    for m in st.session_state.messages:
        role = "Consultant" if m["role"] == "assistant" else "User"
        doc += f"**{role}:** {m['content']}\n\n"
    return doc

# --- UI Layout ---
st.title("🚀 ThinkingPods: Mission Control")

with st.sidebar:
    st.header("💾 Mission Memory")

    # Save/Load UI
    project_name = st.text_input("Project Name", value="MyProject", key="project_name")
    if st.button("Save Mission"):
        save_session(project_name)
        st.success(f"Saved to {project_name}")

    try:
        existing_sessions = [f.replace(".json", "") for f in os.listdir(SESSION_DIR) if f.endswith(".json")]
    except FileNotFoundError:
        existing_sessions = []
    if existing_sessions:
        selected_session = st.selectbox("Load Mission", ["None"] + existing_sessions)
        if selected_session != "None" and st.button("Load Now"):
            load_session(selected_session)
            st.rerun()

    st.divider()

    # Interaction Mode Selector (ChatGPT-like feature)
    st.header("💬 Interaction Mode")
    interaction_mode = st.selectbox(
        "Choose AI behavior:",
        ["Design Thinking Coach", "Helpful Assistant", "Balanced"],
        index=1,  # Default to Helpful Assistant (more ChatGPT-like)
        help="Design Thinking Coach: Follows DT framework strictly\nHelpful Assistant: More conversational and solution-oriented\nBalanced: Mix of both approaches"
    )
    st.session_state.interaction_mode = interaction_mode

    st.divider()
    st.header("🛤️ Journey Status")
    st.markdown(f"**Current Phase:** `{st.session_state.dt_phase}`")

    if st.session_state.get("interaction_mode") == "Design Thinking Coach" and st.session_state.get("dt_phase") in ("Discovery", "empathize", "general"):
        st.subheader("📋 Empathize Checklist")
        # Fetch status from backend
        try:
            status_res = requests.post(f"{BACKEND_URL}/session/status", json={
                "username": "User",
                "project_name": st.session_state.get("project_name", "MyProject")
            })
            if status_res.status_code == 200:
                status_data = status_res.json()
                
                # Render Checklist Cards
                checklist = status_data.get("checklist", {})
                for key, item in checklist.items():
                    complete = item["complete"]
                    desc = item["description"].title()
                    val = item["value"]
                    
                    if complete:
                        badge = '<span class="badge-complete">✓ Complete</span>'
                        val_html = f'<div class="card-value">{val}</div>'
                    else:
                        badge = '<span class="badge-missing">✗ Missing</span>'
                        val_html = '<div class="card-value" style="color: #6b7280; font-style: normal;">Not gathered yet</div>'
                        
                    st.markdown(f"""
                    <div class="checklist-card">
                        {badge}
                        <div class="card-header">{desc}</div>
                        {val_html}
                    </div>
                    """, unsafe_allow_html=True)
                
                # Show extracted facts
                known_facts = status_data.get("known_facts", [])
                if known_facts:
                    st.subheader("💡 Extracted Facts")
                    for fact in known_facts:
                        st.markdown(f"- {fact}")
                        
                # Show assumptions
                assumptions = status_data.get("assumptions", [])
                if assumptions:
                    st.subheader("🔍 Assumptions")
                    for asm in assumptions:
                        st.markdown(f"- *{asm}*")
                        
                # Show unknown facts
                unknown_facts = status_data.get("unknown_facts", [])
                if unknown_facts:
                    st.subheader("❓ Unknown Facts")
                    for unk in unknown_facts:
                        st.markdown(f"- {unk}")
                        
                # Show open questions
                open_questions = status_data.get("open_questions", [])
                if open_questions:
                    st.subheader("💬 Open Questions")
                    for q in open_questions:
                        st.markdown(f"- {q}")
            else:
                st.warning("Could not sync mentor session status.")
        except Exception as e:
            st.warning("Backend offline / status unavailable.")

    if st.button("Move to Requirements Phase"):
        st.session_state.dt_phase = "Requirements"
        st.rerun()
    if st.button("Back to Discovery"):
        st.session_state.dt_phase = "Discovery"
        st.rerun()

    st.divider()
    st.header("🔍 Analysis Tools")
    col_a, col_b = st.columns(2)
    trigger_critique = col_a.button("🛡️ Critique")
    trigger_visualize = col_b.button("🗺️ Visualize")
    
    st.divider()
    st.header("✨ AI Power Tools")
    trigger_reqgpt = st.button("💎 Generate ISO Requirements")
    if trigger_reqgpt:
        with st.spinner("🚀 Calling specialized ReqGPT model..."):
            # Use the last user message or a generic prompt
            last_user_msg = next((m["content"] for m in reversed(st.session_state.messages) if m["role"] == "user"), "Requirement: The system shall")
            specialized_req = call_backend_reqgpt(last_user_msg)
            st.session_state.messages.append({"role": "assistant", "content": f"**Specialized Requirement:**\n\n{specialized_req}"})
            st.rerun()

    st.divider()
    st.header("📄 Export")
    if "prd_content" not in st.session_state:
        st.session_state.prd_content = None
    if st.button("Prepare PRD"):
        st.session_state.prd_content = format_prd()
    if st.session_state.prd_content:
        st.download_button(
            label="Download .md PRD",
            data=st.session_state.prd_content,
            file_name=f"{project_name}_PRD.md",
            mime="text/markdown"
        )

    st.divider()
    st.header("🗄️ Knowledge Vault")
    uploaded_file = st.file_uploader("Upload Project Context", type=["txt", "md", "csv"])
    doc_context = ""
    if uploaded_file:
        try:
            doc_context = uploaded_file.read().decode("utf-8")
        except UnicodeDecodeError:
            doc_context = uploaded_file.read().decode("utf-8", errors="replace")
            st.warning("File contained non-UTF-8 characters; some content may be garbled.")
        st.success(f"Document Ingested (Limited to ~2000 chars for memory safety)")

    st.divider()
    if st.button("🗑️ Clear Mission / Start Over"):
        try:
            requests.post(f"{BACKEND_URL}/reset", json={
                "username": "User",
                "project_name": st.session_state.get("project_name", "MyProject")
            })
        except Exception as e:
            pass
        st.session_state.messages = [{"role": "assistant", "content": "Hello! I am ThinkingPods. Let's start fresh. What's the idea?"}]
        st.session_state.dt_phase = "Discovery"
        st.rerun()

    st.divider()
    st.header("🎤 Voice Interface")
    audio_bytes = audio_recorder(text="Click to Speak", icon_size="2x", key="recorder")
    enable_voice = st.checkbox("Enable AI Voice Replies", value=True, key="enable_voice")

# Display Chat History
for idx, message in enumerate(st.session_state.messages):
    with st.chat_message(message["role"]):
        st.markdown(message["content"])
        # Detect any mermaid keywords in the message to trigger rendering
        if any(k in message["content"] for k in MERMAID_KEYWORDS):
            render_mermaid(message["content"])
        
        # Play and show audio if present
        if message["role"] == "assistant" and message.get("audio"):
            if enable_voice:
                try:
                    audio_data = base64.b64decode(message["audio"])
                    autoplay_flag = not message.get("audio_played", False)
                    st.audio(audio_data, format="audio/wav", autoplay=autoplay_flag, key=f"audio_{idx}")
                    if autoplay_flag:
                        message["audio_played"] = True
                except Exception as e:
                    st.error(f"Error playing audio: {e}")

# --- Process Specialized Tasks ---
if trigger_critique:
    with st.spinner("🔍 Auditing requirements..."):
        ai_reply, audio_reply = call_backend_text("Critique the requirements for weak words.", st.session_state.dt_phase, doc_ctx=doc_context)
        audio_b64 = base64.b64encode(audio_reply).decode('utf-8') if audio_reply else None
        st.session_state.messages.append({
            "role": "assistant",
            "content": ai_reply,
            "audio": audio_b64,
            "audio_played": False
        })
        st.rerun()

if trigger_visualize:
    with st.chat_message("assistant"):
        with st.spinner("🗺️ Mapping logic..."):
            diagram_code = call_backend_visualize(username="User", doc_ctx=doc_context)
            # Add to history as a diagram block
            full_reply = f"Here is the system visualization:\n\n```mermaid\n{diagram_code}\n```"
            st.markdown(full_reply)
            render_mermaid(diagram_code)
            st.session_state.messages.append({"role": "assistant", "content": full_reply})

# --- Input Handlers ---
if audio_bytes and audio_bytes != st.session_state.get("last_audio_bytes"):
    with st.spinner("👂 Hearing and thinking..."):
        transcript, ai_reply, audio_reply = call_backend_voice(audio_bytes, st.session_state.get("dt_phase", "Discovery"), doc_ctx=doc_context)
        if ai_reply and ai_reply.startswith("⚠️"):
            st.session_state.last_audio_bytes = audio_bytes
            st.error(ai_reply)
        elif transcript or ai_reply:
            st.session_state.last_audio_bytes = audio_bytes
            user_msg = transcript if transcript else "🎤 *[Silence / Mic Check]*"
            st.session_state.messages.append({"role": "user", "content": user_msg})
            audio_b64 = base64.b64encode(audio_reply).decode('utf-8') if audio_reply else None
            st.session_state.messages.append({
                "role": "assistant",
                "content": ai_reply,
                "audio": audio_b64,
                "audio_played": False
            })
            st.rerun()
        else:
            st.session_state.last_audio_bytes = audio_bytes
            st.warning("I couldn't quite hear that. Could you try again? 🎤")

user_input = st.chat_input("Type your reply here...")

# --- Process Input ---
if user_input:
    st.session_state.messages.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)

    with st.chat_message("assistant"):
        with st.spinner("🧠 Thinking..."):
            ai_reply, audio_reply = call_backend_text(user_input, st.session_state.get("dt_phase", "Discovery"), doc_ctx=doc_context)
            st.markdown(ai_reply)
            audio_b64 = base64.b64encode(audio_reply).decode('utf-8') if audio_reply else None
            st.session_state.messages.append({
                "role": "assistant",
                "content": ai_reply,
                "audio": audio_b64,
                "audio_played": False
            })
            st.rerun()